var numero1 = require('../models/numeros');
var synaptic = require('synaptic'); // this line is not needed in the browser
module.exports = {
   
    insertar:function(req,res,next){
        var numero = new numero1(req.body);
        var nombre=numero.numero;

        function miRed(){
            var inputlayer=new synaptic.Layer(60);
            var hiddenlayer=new synaptic.Layer(3);
            var hiddenlayer2=new synaptic.Layer(3);
            var outputlayer=new synaptic.Layer(1);

            inputlayer.project(hiddenlayer);
            hiddenlayer.project(hiddenlayer2);
            hiddenlayer2.project(outputlayer);
            this.set(
                {input:inputlayer,
                hidden:[hiddenlayer,hiddenlayer2],
                output:outputlayer}
            );
        }
            miRed.prototype=new synaptic.Network();
            miRed.prototype.constructor=miRed;


            var caso0=[1,1,1,1,1,1,1,0,0,0,0,1,1,0,0,0,0,1,1,0,0,0,0,1,1,0,0,0,0,1,1,0,0,0,0,1,1,0,0,0,0,1,1,0,0,0,0,1,1,0,0,0,0,1,1,1,1,1,1,1];
            var caso1=[0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,0,0,1];
            var caso2=[1,1,1,1,1,1,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,0,0,1,1,1,1,1,1,1,1,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,0,0,1,1,1,1,1,1];
            var caso3=[1,1,1,1,1,1,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,0,0,1,0,1,1,1,1,1,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,0,0,1,1,1,1,1,1,1];
            var caso4=[1,0,0,0,0,1,1,0,0,0,0,1,1,0,0,0,0,1,1,0,0,0,0,1,1,1,1,1,1,1,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,0,0,1];
            var caso5=[1,1,1,1,1,1,1,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,0,0,1,1,1,1,1,1,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,0,0,1,1,1,1,1,1,1];
            var caso6=[1,1,1,1,1,1,1,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,0,0,1,1,1,1,1,1,1,0,0,0,0,1,1,0,0,0,0,1,1,0,0,0,0,1,1,0,0,0,0,1,1,1,1,1,1,1];
            var caso7=[1,1,1,1,1,1,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,0,0,1];
            var caso8=[1,1,1,1,1,1,1,0,0,0,0,1,1,0,0,0,0,1,1,0,0,0,0,1,1,1,1,1,1,1,1,0,0,0,0,1,1,0,0,0,0,1,1,0,0,0,0,1,1,0,0,0,0,1,1,1,1,1,1,1];
            var caso9=[1,1,1,1,1,1,1,0,0,0,0,1,1,0,0,0,0,1,1,0,0,0,0,1,1,1,1,1,1,1,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,0,0,1,1,1,1,1,1,1];
            
            
            var rn=new miRed();
            var entrenar=new synaptic.Trainer(rn);
            
            
            entrenar.train([
                {input:caso0,output:[0.1]
                },{input:caso1,output:[0.2]
                },{input:caso2,output:[0.3]
                },{input:caso3,output:[0.4]
                },{input:caso4,output:[0.5]
                },{input:caso5,output:[0.6]
                },{input:caso6,output:[0.7]
                },{input:caso7,output:[0.8]
                },{input:caso8,output:[0.9]
                },{input:caso9,output:[1]
                }
            ],{
                iterations:100000000,
                cost:synaptic.Trainer.cost.MSE,
                shuffle:true,
                log:false
            });
            console.log (nombre);
            var varia=nombre;
            var X1=rn.activate(varia);
            //console.log (X1);
            
            if(X1<0.4){
            
                Paso1(1,caso0,caso1,caso2,caso3);
            }
            else{
                if (X1<0.79){
                   Paso1(2,caso3,caso4,caso5,caso6);
                }
                else{
                    Paso1(3,caso6,caso7,caso8,caso9);
                }
            }
            
            
            
            function Paso1(tipo,cas1,cas2,cas3,cas4)
            {
                var rn1=new miRed();
                var entrenar1=new synaptic.Trainer(rn1); 
                entrenar1.train([
                    {input:cas1,output:[0]
                    },{input:cas2,output:[0.5]
                    },{input:cas3,output:[0.75]
                    },{input:cas4,output:[1]
                    }
                ],{
                    iterations:10000000,
                    cost:synaptic.Trainer.cost.MSE,
                    shuffle:true,
                    log:false
                });
                var XS=rn1.activate(varia);
            
                    console.log ("------------------------------------------------------");
            
                    if(tipo==1){mostrar(1,XS)}
                    if(tipo==2){mostrar(2,XS)}
                    if(tipo==3){mostrar(3,XS)}
            }
            
            function mostrar(Y1,XS)
            {
            
                switch(Y1) {
                    case 1:
                        if (XS<0.39){console.log ("0");
                        return res.json({bien:"0", msg:varia, errors: false});
                    } 
                        else{   
                        if (XS<0.59){console.log ("1");return res.json({bien:"1", msg:varia, errors: false});
                    }
                        else{
                        if (XS<0.79){console.log ("2");
                        return res.json({bien:"2", msg:varia, errors: false});
                    }
                        else{
                        if (XS<1){console.log ("3");
                        return res.json({bien:"3", msg:varia, errors: false});
                    }}}} 
                        break;
                    case 2:
                        if (XS<0.39){console.log ("3");
                        return res.json({bien:"3", msg:varia, errors: false});
                    } 
                        else{   
                        if (XS<0.59){console.log ("4");
                        return res.json({bien:"4", msg:varia, errors: false});
                    }
                        else{
                        if (XS<0.79){console.log ("5");
                        return res.json({bien:"5", msg:varia, errors: false});
                    }
                        else{
                        if (XS<1){console.log ("6");
                        return res.json({bien:"6", msg:varia, errors: false});
                    }}}} 
                        break;
                    case 3:
                        if (XS<0.39){console.log ("6");
                        return res.json({bien:"6", msg:varia, errors: false});
                    } 
                        else{   
                        if (XS<0.59){console.log ("7");return res.json({bien:"7", msg:varia, errors: false});
                    }
                        else{
                        if (XS<0.79){console.log ("8");
                            return res.json({bien:"8", msg:varia, errors: false});}
                        else{
                        if (XS<1){
                            console.log ("9");
                            return res.json({bien:"9", msg:varia, errors: false});

                        }}}} 
                        break;
                    default:
                      // code block
                  }
            }



                
        //return res.json({bien:caso0, msg:"ERROR!!", errors: numero});



    }

}