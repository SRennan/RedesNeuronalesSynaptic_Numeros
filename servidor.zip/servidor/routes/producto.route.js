var express = require('express');
var router = express.Router();
let controller = require('../controllers/producto.controller');

/* GET home page. */
router.post('/insertar',controller.insertar);

module.exports = router;
