var mongoose = require('mongoose');
let schema = mongoose.Schema({
    numero: {
        type:String,
        required: [true,"Este campo es requerido."],
        unique: [true,"Nombre ya en uso"]
    }
},
{
    collection:'tbnumeros',
    timestamps: true
}
);
module.exports=mongoose.model('tbnumeros',schema);

