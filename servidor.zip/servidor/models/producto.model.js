var mongoose = require('mongoose');
let schema = mongoose.Schema({
    nombre: {
        type:String,
        required: [true,"Este campo es requerido."],
        unique: [true,"Nombre ya en uso"]
    },
    precio:{
        type:Number,
        required: [true,"Este campo es requerido."]
    },
    cantidad:{
        type:Number,        
        required: [true,"Este campo es requerido."]
    },
    estado: {
        type: Number,
        default: 1
    }
},
{
    collection:'tbproducto',
    timestamps: true
}
);
module.exports=mongoose.model('tbproducto',schema);

